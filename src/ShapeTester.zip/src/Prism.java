
public class Prism {
	// Member variables
	private double b,h,l,s1,s2,s3;
	
	// Constructor
	Prism() {
		this.b=0;
		this.h=0;
		this.l=0;
		this.s1=0;
		this.s2=0;
		this.s3=0;
	}
	
	

	/*Prism(double l, double w, double h) {
		this.l1 = l;
		this.w = w;
		this.h = h;
	}*/
	
	
	public void setB(double b) {
		this.b = b;
	}
	

	public void setH(double h) {
		this.h = h;
	}
	

	public void setL(double l) {
		this.l = l;
	}


	public void setS1(double s1) {
		this.s1 = s1;
	}

	
	public void setS2(double s2) {
		this.s2 = s2;
	}


	public void setS3(double s3) {
		this.s3 = s3;
	}



	public double calcVol() {
		double vol = (l*b*h)/2;
		return vol;
	}
	
	public double calcSurfArea() {
		double sa = b*h + l*(s1 + s2 + s3);
		return sa;
	}

}
