import java.util.Scanner;

public class ShapeTester {

	public static void main(String[] args) {
		// Get values from the user with scanner
		Scanner scan = new Scanner(System.in);
		Cuboid c1 = new Cuboid();
		Prism p1 = new Prism();
		Sphere s1 = new Sphere();
		boolean play = true;
		
		// Welcome User
		System.out.println("Welcome to the Shape Tester! Type 1 for a cuboid, 2 for a prism, and 3 for a sphere");
		while(play == true) {
			int shape = scan.nextInt();
			if (shape == 1) {
				System.out.println("What is the length?");
			    double val = scan.nextDouble();
			    c1.setL(val);


			    System.out.println("What is the width?");
			    val = scan.nextDouble();
			    c1.setW(val);


			    System.out.println("What is the height?");
			    val = scan.nextDouble();
			    c1.setH(val);
	

			    System.out.println("The volume is: " + c1.calcVol());
			    
			    System.out.println("The surface area is: " + c1.calcSurfArea());
			} else if(shape == 2) {
				System.out.println("What is the length of the base?");
			    double val = scan.nextDouble();
			    p1.setB(val);


			    System.out.println("What is the height?");
			    val = scan.nextDouble();
			    p1.setH(val);


			    System.out.println("What is the length?");
			    val = scan.nextDouble();
			    p1.setL(val);

			    System.out.println("What is the length of side one?");
			    val = scan.nextDouble();
			    p1.setS1(val);
			    
			    System.out.println("What is the length of side two?");
			    val = scan.nextDouble();
			    p1.setS2(val);
			    
			    System.out.println("What is the length of side three?");
			    val = scan.nextDouble();
			    p1.setS3(val);

			    System.out.println("The volume is: " + p1.calcVol());
			    
			    System.out.println("The surface area is: " + p1.calcSurfArea());
			} else {
				System.out.println("What is the radius?");
			    double val = scan.nextDouble();
			    s1.setR(val);

			    System.out.println("The volume is: " + s1.calcVol());
			    
			    System.out.println("The surface area is: " + s1.calcSurfArea());
			}
			System.out.println("Again? 1 for yes, 2 for no.");
			int again = scan.nextInt();
			if (again == 2) {
				play = false;
			} else {
				System.out.println("Type another number to do another shape!");
			}
		}
		System.out.println("Thanks!");

	}

}
