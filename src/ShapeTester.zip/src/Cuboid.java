
public class Cuboid {
	// Member variables
	private double l,w,h;
	
	// Constructor
	Cuboid() {
		this.l=0;
		this.w=0;
		this.h=0;
	}
	
	public void setL(double l) {
		this.l = l;
	}
	
	public void setW(double w) {
		this.w = w;
	}
	
	public void setH(double h) {
		this.h = h;
		
	}
	
	Cuboid(double l, double w, double h) {
		this.l = l;
		this.w = w;
		this.h = h;
	}
	
	public double calcVol() {
		double vol = l*w*h;
		return vol;
	}
	
	public double calcSurfArea() {
		double sa = 2*l*h + 2*w*l + 2*h*w;
		return sa;
	}

}
