import java.lang.Math;

public class Sphere {
  // Member Variables
  private double r;
  private double pi;

  // Constructor
  public Sphere() {
    r = 0.0;
    pi = 3.14;
  }

  // Set Methods
  public void setR(double r) {
    this.r = r;
  }

  // Calculation Methods
  public double calcVol() {
    double vol = 1.3333334*pi*(Math.pow(r, 3));
    return vol;
  }
  public double calcSurfArea() {
    double sa = 4*pi*Math.pow(r, 2);
    return sa;
  }
}