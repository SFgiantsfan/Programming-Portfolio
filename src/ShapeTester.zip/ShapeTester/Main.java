import java.util.Scanner;

class Main {
  public static void main(String[] args) {
    Scanner scan = new Scanner(System.in);
    Box b1 = new Box();
    Sphere s1 = new Sphere();
    Pyramid p1 = new Pyramid();
    boolean play = true;

    // Welcome User
    System.out.println("Welcome to the Shape Tester!\nType 1 for a box, 2 for a sphere, and 3 for a pyramid:");
    while(play == true){
    int shape = scan.nextInt();
    if(shape == 1){
      System.out.println("What is the length?");
    double val = scan.nextDouble();
    b1.setL(val);
    //System.out.println(val);

    System.out.println("What is the width?");
    val = scan.nextDouble();
    b1.setW(val);
    //System.out.println(val);

    System.out.println("What is the height?");
    val = scan.nextDouble();
    b1.setH(val);
    //System.out.println(val);

    System.out.println("The volume is: " + b1.calcVol());
    
    System.out.println("The surface area is: " + b1.calcSurfArea());
    } else if(shape == 2){
      System.out.println("What is the radius?");
    double val = scan.nextDouble();
    s1.setR(val);
    //System.out.println(val);

    System.out.println("The volume is: " + s1.calcVol());
    
    System.out.println("The surface area is: " + s1.calcSurfArea());
    }else{
      System.out.println("What is the length?");
    double val = scan.nextDouble();
    p1.setL(val);
    //System.out.println(val);

    System.out.println("What is the width?");
    val = scan.nextDouble();
    p1.setW(val);
    //System.out.println(val);

    System.out.println("What is the height?");
    val = scan.nextDouble();
    p1.setH(val);
    //System.out.println(val);

    System.out.println("The volume is: " + p1.calcVol());
    
    System.out.println("The surface area is: " + p1.calcSurfArea());
      }
      System.out.println("Type another number to do another shape!");
    }
  }
}